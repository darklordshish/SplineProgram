# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'PlBel.ui'
#
# Created: Wed Mar  9 08:24:22 2016
#      by: PyQt4 UI code generator 4.11.1
#
# WARNING! All changes made in this file will be lost!
from PlBelPlot import *
#from PyQt4 import QtCore, QtGui, Qt
#import pyqtgraph as pg
from pyqtgraph import PlotWidget
#import numpy as np
import sys
from scipy.optimize import brentq
#from scipy.interpolate import UnivariateSpline
#from numpy.random import rand
import os
import importlib as im
import dill as pickle
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)
        

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(851, 674)
        Form.setMouseTracking(True)
        Form.setAcceptDrops(False)
        Form.setLayoutDirection(QtCore.Qt.LeftToRight)
        
        self.ParamPlBel = PlBelPlot(Form)
        self.ParamPlBel.setGeometry(QtCore.QRect(0, 10, 381, 281))
        
        self.ResPlBel = PlBelPlot(Form)
        self.ResPlBel.setGeometry(QtCore.QRect(470, 10, 381, 281))
        self.ResPlBel.ResPlot=True
        
        self.convertButton = QtGui.QPushButton(Form)
        self.convertButton.setGeometry(QtCore.QRect(400, 20, 51, 31))
        
        self.loadButton = QtGui.QPushButton(Form)
        self.loadButton.setGeometry(QtCore.QRect(540, 300, 121, 25))
        
        self.FunctionPlot = PlotWidget(Form)
        self.FunctionPlot.setGeometry(QtCore.QRect(0, 340, 851, 331))
        self.FunctionPlot.setObjectName(_fromUtf8("FunctionPlot"))
        self.FunctionPlot.function_curve_plot=pg.PlotCurveItem()
        self.FunctionPlot.function_curve_plot.setPen((5, 6))
        self.FunctionPlot.addItem(self.FunctionPlot.function_curve_plot)        
        
        self.spline_degree = QtGui.QSpinBox(Form)
        self.spline_degree.setGeometry(QtCore.QRect(90, 310, 55, 24))
        self.spline_degree.setMinimum(1)
        self.spline_degree.setMaximum(5)
        
        self.label_k = QtGui.QLabel(Form)
        self.label_k.setGeometry(QtCore.QRect(70, 300, 16, 16))
        
        self.steps = QtGui.QSpinBox(Form)
        self.steps.setGeometry(QtCore.QRect(790, 300, 55, 24))
        self.steps.setMinimum(100)
        self.steps.setMaximum(5000)
        self.steps.setProperty("value", 400)
        
        self.label_steps = QtGui.QLabel(Form)
        self.label_steps.setGeometry(QtCore.QRect(680, 300, 111, 31))
        
        self.x_min = QtGui.QDoubleSpinBox(Form)
        self.x_min.setGeometry(QtCore.QRect(190, 310, 62, 24))
        self.x_min.setProperty("value", self.ParamPlBel.xMin)
        self.x_min.setMinimum(-100000.0)
        self.x_min.setMaximum(100000.0)
        self.x_min.setProperty("value", self.ParamPlBel.xMin)
        
        self.x_max = QtGui.QDoubleSpinBox(Form)
        self.x_max.setGeometry(QtCore.QRect(310, 310, 62, 24))
        self.x_max.setProperty("value", self.ParamPlBel.xMax)
        self.x_max.setMinimum(-100000.0)
        self.x_max.setMaximum(100000.0)
        self.x_max.setProperty("value", self.ParamPlBel.xMax)
        
        self.label_x_min = QtGui.QLabel(Form)
        self.label_x_min.setGeometry(QtCore.QRect(150, 300, 41, 16))
        
        self.label_xmax = QtGui.QLabel(Form)
        self.label_xmax.setGeometry(QtCore.QRect(260, 300, 41, 16))
        
        self.clear_PlBel_res = QtGui.QPushButton(Form)
        self.clear_PlBel_res.setGeometry(QtCore.QRect(480, 300, 51, 25))
        
        self.clear_PlBel_param = QtGui.QPushButton(Form)
        self.clear_PlBel_param.setGeometry(QtCore.QRect(10, 300, 51, 25))

        self.ParamToRes = QtGui.QRadioButton(Form)
        self.ParamToRes.setGeometry(QtCore.QRect(400, 70, 51, 20))
        self.ParamToRes.setCheckable(True)
        self.ParamToRes.setChecked(True)

        self.ResToParam = QtGui.QRadioButton(Form)
        self.ResToParam.setGeometry(QtCore.QRect(400, 100, 51, 20))
        self.ResToParam.setChecked(False)

        self.SaveButton = QtGui.QPushButton(Form)
        self.SaveButton.setGeometry(QtCore.QRect(400, 260, 51, 25))

        self.LoadButton = QtGui.QPushButton(Form)
        self.LoadButton.setGeometry(QtCore.QRect(400, 230, 51, 25))

        self.num=400
        self.PlotFunction()        
                
        
        QtCore.QObject.connect(self.convertButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.ConvertPlBel)
        QtCore.QObject.connect(self.loadButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.changing_function)
        QtCore.QObject.connect(self.SaveButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.save_model)
        QtCore.QObject.connect(self.LoadButton, QtCore.SIGNAL(_fromUtf8("clicked()")), self.load_model)
        QtCore.QObject.connect(self.clear_PlBel_param, QtCore.SIGNAL(_fromUtf8("clicked()")), self.ClearParamPlBel)
        QtCore.QObject.connect(self.clear_PlBel_res, QtCore.SIGNAL(_fromUtf8("clicked()")), self.ClearResPlBel)
        QtCore.QObject.connect(self.spline_degree, QtCore.SIGNAL(_fromUtf8("valueChanged(int)")), self.ParamPlBel.changeK)
        QtCore.QObject.connect(self.spline_degree, QtCore.SIGNAL(_fromUtf8("valueChanged(int)")), self.ResPlBel.changeK)
        QtCore.QObject.connect(self.x_min, QtCore.SIGNAL(_fromUtf8("valueChanged(double)")), self.ParamPlBel.changeXmin)
        QtCore.QObject.connect(self.x_max, QtCore.SIGNAL(_fromUtf8("valueChanged(double)")), self.ParamPlBel.changeXmax)
        QtCore.QObject.connect(self.steps, QtCore.SIGNAL(_fromUtf8("valueChanged(int)")), self.ParamPlBel.changeNum)
        QtCore.QObject.connect(self.steps, QtCore.SIGNAL(_fromUtf8("valueChanged(int)")), self.ResPlBel.changeNum)
        QtCore.QObject.connect(self.steps, QtCore.SIGNAL(_fromUtf8("valueChanged(int)")), self.changeNum)
        QtCore.QObject.connect(self.ParamPlBel, QtCore.SIGNAL(_fromUtf8("change()")), self.PlotFunction)
        QtCore.QObject.connect(self.ParamToRes, QtCore.SIGNAL(_fromUtf8("changeEvent()")),self.SetParamToRes)
        QtCore.QObject.connect(self.ResToParam, QtCore.SIGNAL(_fromUtf8("changeEvent()")), self.SetResToParam)
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def f(self,x):#функция,для значений которой мы расчитываем правдоподобие и доверие
        return x/(x+1)*np.exp(-1.58*x/(x+1))#np.sin(2*x)*(x**2-5*x+2)

    def PlotFunction(self):
        x_grid=np.linspace(self.ParamPlBel.xMin,self.ParamPlBel.xMax,self.num)
        y_grid=self.f(x_grid)
        self.FunctionPlot.function_curve_plot.setData(x_grid,y_grid)      
    
    def changeNum(self,num):
        if num>=100 and num<=5000:
            self.num=num
            self.ConvertPlBel()    
            self.PlotFunction()            
            
    def ClearParamPlBel(self):
        self.ParamPlBel.pl_grid=np.ones(self.ResPlBel.num)
        self.ParamPlBel.bel_grid=np.zeros(self.ResPlBel.num)
        self.ParamPlBel.points_x=np.array([])
        self.ParamPlBel.points_t=np.array([])
        self.ParamPlBel.pointsPlot.clear()
        self.ParamPlBel.distributionPlPlot.clear()
        self.ParamPlBel.distributionBelPlot.clear()
        self.ParamPlBel.distribution=lambda x: np.ones_like(x)
        self.ParamPlBel.plotInterpolation()

    def ClearResPlBel(self):
        self.ResPlBel.pl_grid=np.ones(self.ResPlBel.num)
        self.ResPlBel.bel_grid=np.zeros(self.ResPlBel.num)
        self.ResPlBel.points_x=np.array([])
        self.ResPlBel.points_t=np.array([])
        self.ResPlBel.distributionPlPlot.clear()
        self.ResPlBel.distributionBelPlot.clear()
        self.ResPlBel.distribution=lambda x: np.ones_like(x)
        self.ResPlBel.plotInterpolation()
    
    def changing_function(self):
        fname = QtGui.QFileDialog.getOpenFileName(QtGui.QWidget(), _fromUtf8("Open file"),
                _fromUtf8("."), filter="Python modules (*.py *.pyc *.pyo *.pyd);;MATLAB functions (*.m)")#создаём диалог выбора файла, на выходе имеем имя файла
        print(fname)
        directory, module_name = os.path.split(fname)
        module_name =os.path.splitext(module_name)[0]
        
        path = list(sys.path)
        sys.path.insert(0, directory) # Добавление директории с модулем в PATH на первое место
        try: #пробуем поменять функцию собственную f(.) на функцию f(.) из файла, возвращённого диалоговым окном выбора файла
            fn = im.import_module(module_name)
            print(dir(fn))
            self.f=fn.f#собственно, меняем
        except  (ValueError):#, TypeError, SyntaxError, NameError,AttributeError):# если не получилось поменять и выскочила ошибка
            print("function f(x) not found!")# пишем в консоли, что функция f(.) не найдена
        finally:
            sys.path[:] = path # Восстановление исходного PATH
        self.PlotFunction()
        self.ConvertPlBel()
        
    def save_model(self):
        
        data={ "function":self.f,
               "alpha":self.ParamPlBel.alpha,
               "ParamDistribution":[self.ParamPlBel.points_x , self.ParamPlBel.points_t],
               "ResDistribution":[self.ResPlBel.points_x , self.ResPlBel.points_t],
               "Spline":[self.ParamPlBel.k , self.ParamPlBel.s],
               "minX":self.ParamPlBel.xMin,
               "maxX":self.ParamPlBel.xMax,
               "number_of_steps":self.num}
        print(data)
        fname = QtGui.QFileDialog.getSaveFileName(QtGui.QWidget(),_fromUtf8("Save Model"),
                _fromUtf8("."), filter="*.pickle")#"Python modules (*.py *.pyc *.pyo *.pyd);;MATLAB functions (*.m)")
        with open(fname,'wb') as save_file:
            pickle.dump(data,save_file)

        
    def load_model(self):
        fname = QtGui.QFileDialog.getOpenFileName(QtGui.QWidget(),_fromUtf8("Load Model"),
                _fromUtf8("."), filter="*.pickle")
        with open(fname,'rb') as load_file:
            new_data=pickle.load(load_file)
        print(new_data)
        
        self.f=new_data['function']
        self.ParamPlBel.alpha=new_data['alpha']
        self.ResPlBel.alpha=new_data['alpha']
        self.num=new_data['number_of_steps']
        self.ParamPlBel.num=new_data['number_of_steps']
        self.ResPlBel.num=new_data['number_of_steps']
        self.ParamPlBel.points_x=new_data['ParamDistribution'][0]
        self.ParamPlBel.points_t=new_data['ParamDistribution'][1]
        self.ResPlBel.points_x=new_data['ResDistribution'][0]
        self.ResPlBel.points_t=new_data['ResDistribution'][1]
        self.ParamPlBel.k=new_data['Spline'][0]
        self.ParamPlBel.s=new_data['Spline'][1]
        self.ResPlBel.k=new_data['Spline'][0]
        self.ResPlBel.s=new_data['Spline'][1]
        self.ParamPlBel.xMin=new_data['minX']
        self.ParamPlBel.xMax=new_data['maxX']
        
        self.ParamPlBel.pointsPlot.setData(self.ParamPlBel.points_x, self.ParamPlBel.points_t)
        self.ResPlBel.pointsPlot.setData(self.ResPlBel.points_x, self.ResPlBel.points_t)     
        self.ConvertPlBel()
        self.PlotFunction()
        
        
    def ConvertPlBel(self):
        if self.ParamToRes.isChecked()==True:
            self.SetParamToRes()
            self.ParamPlBel.recalcInterpolation(self.ParamPlBel.k,self.ParamPlBel.s)
            self.ParamPlBel.plotInterpolation()
            self.ResPlBelPlot()
        elif self.ResToParam.isChecked()==True:
            self.SetResToParam()
            self.ResPlBel.recalcInterpolation(self.ResPlBel.k,self.ResPlBel.s)
            self.ResPlBel.plotInterpolation()
            self.ParPlBelPlot()
            
    def ResPlBelPlot(self):#посчитаем распределение правдоподобия и доверия значений функции f(x)  

        x_grid=np.linspace(self.ParamPlBel.xMin,self.ParamPlBel.xMax,self.num)#построим сетку на области определения функции
        y=self.f(x_grid)#вычислим значения функции в точках сетки
        self.ResPlBel.xMin=np.min(y)#установим для расчёта распределения правдоподобия и доверия значений функции
        self.ResPlBel.xMax=np.max(y)#максимальное и минимальное значения из вычисленных на сетке параметра х
        y_iterate=np.linspace(self.ResPlBel.xMin,self.ResPlBel.xMax,self.num)#построим сетку в области значений функции
        self.ResPlBel.pl_grid=np.array([])#обновим распределение правдоподобия
        self.ResPlBel.bel_grid=np.array([])#и доверия
        for j in range(self.num):#начнём вычисления
            g=lambda x: self.f(x)-y_iterate[j]#найдём для каждого y из все х, которые его доставляют, построим новую функцию g(x) и будем искать её корни
            roots=g(x_grid)#сетка значений новой функции g(x)
            sign_roots=np.sign(roots)#знаки значений функции
            x_pos=np.array([])#создадим массив корней функции g(x)
            for i in range(self.num-1):#
                k=0#счётчик позиции для вставки найденного корня
                if sign_roots[i]+sign_roots[i+1] == 0:#если знак начений функции на концах интервала разный, значин на нём есть корень, хотя бы один               
                    x0=brentq(g, x_grid[i], x_grid[i+1])#найдём корень
                    x_pos=np.insert(x_pos,k,x0)#вставим корень в массив корней на позицию k
                    k=k+1#увеличим счётчик корней на один
            if np.size(x_pos)==0:#если корней нет, то 
                self.ResPlBel.pl_grid=np.append(self.ResPlBel.pl_grid, 0.0)#правдоподобие значения y_iterate[j] равно нулю
                self.ResPlBel.bel_grid=np.append(self.ResPlBel.bel_grid, self.ParamPlBel.theta(0.0))#а доверие  единице
            else:#если корни есть, тогда
                self.ResPlBel.pl_grid=np.append(self.ResPlBel.pl_grid, np.max(self.ParamPlBel.distribution(x_pos)))#находим из корней тот, правдоподобие которого максимально и приравниваем его правдоподобие правдоподобию соответствующего значения функции
                self.ResPlBel.bel_grid=np.append(self.ResPlBel.bel_grid, np.min(self.ParamPlBel.theta(self.ParamPlBel.distribution(x_pos))))#находим из корней тот, доверие которого минимально и приравниваем его доверие доверию соостветствующего значения функции
        self.ResPlBel.plotInterpolation()#рисуем

    def ParPlBelPlot(self):
        x_grid=np.linspace(self.ParamPlBel.xMin,self.ParamPlBel.xMax,self.num)
        y=self.f(x_grid)
        self.ResPlBel.xMin=np.min(y)
        self.ResPlBel.xMax=np.max(y)
        self.ParamPlBel.pl_grid=self.ResPlBel.distribution(y)
        self.ParamPlBel.bel_grid=self.ResPlBel.theta(self.ResPlBel.distribution(y))
        self.ParamPlBel.plotInterpolation()
        
    def SetParamToRes(self):
        self.ParamPlBel.ResPlot=False
        self.ResPlBel.ResPlot=True
        
    def SetResToParam(self):
        self.ParamPlBel.ResPlot=True
        self.ResPlBel.ResPlot=False
        
    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "PlBel", None))
        self.convertButton.setText(_translate("Form", "<=>", None))
        self.loadButton.setText(_translate("Form", "Load function", None))
        self.label_k.setText(_translate("Form", "k:", None))
        self.label_steps.setText(_translate("Form", "number of steps:", None))
        self.label_x_min.setText(_translate("Form", "X min:", None))
        self.label_xmax.setText(_translate("Form", "X max:", None))
        self.clear_PlBel_res.setText(_translate("Form", "Clear", None))
        self.ParamToRes.setText(_translate("Form", "=>", None))
        self.ResToParam.setText(_translate("Form", "<=", None))
        self.SaveButton.setText(_translate("Form", "Save", None))
        self.LoadButton.setText(_translate("Form", "Load", None))
        self.clear_PlBel_param.setText(_translate("Form", "Clear", None))
        

app = QtGui.QApplication(sys.argv)
window = QtGui.QMainWindow()
ui= Ui_Form()
ui.setupUi(window)
window.show()
sys.exit(app.exec_())
